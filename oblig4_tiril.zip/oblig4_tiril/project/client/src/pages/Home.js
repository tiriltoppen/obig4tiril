import Movies from '../components/Movies';

const Home = () => (
    <section>
<h2>hey</h2>
    <Movies />
</section>
);

export default Home;