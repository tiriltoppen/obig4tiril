import React from "react";
//import Movies from './Movies';
//import Title from './Title';
//import Actor from './Actor';


const Movie = ({title, actor}) => (
   <li>
        <p>{title}</p>
        <p>{actor}</p>
          
    </li>
 );
  
  

    
export default Movie;



