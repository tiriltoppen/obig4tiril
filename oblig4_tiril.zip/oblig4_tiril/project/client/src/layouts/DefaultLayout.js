/**
 * Her kan du tilpasse layouten som du vil.
 * Du kan også lage flere slike filer om du vil ha flere layouter
 * */
 const DefaultLayout = ({ children }) => (
    <>
      <main>{children}</main>
    </>
  );
  
  export default DefaultLayout;